"""Dependency-free regression checks against the supplied gate and added indicator."""
import importlib.util,sys,types,json
from pathlib import Path
from unittest.mock import patch
root=Path(__file__).resolve().parents[1]
class String:
 def __init__(self,data=''):self.data=data
class Twist:
 def __init__(self):self.linear=types.SimpleNamespace(x=0.,y=0.,z=0.);self.angular=types.SimpleNamespace(x=0.,y=0.,z=0.)
class TS:
 def __init__(self):self.header=types.SimpleNamespace(stamp=None,frame_id='');self.twist=Twist()
class Pub:
 def __init__(self):self.values=[]
 def publish(self,m):self.values.append(m)
class Node:
 def __init__(self,*a):pass
 def declare_parameter(self,n,v):return types.SimpleNamespace(value=v)
 def create_publisher(self,*a):return Pub()
 def create_subscription(self,*a):return object()
 def create_client(self,*a):raise AssertionError('sound disabled in test')
 def create_timer(self,*a):return object()
 def get_logger(self):return types.SimpleNamespace(info=lambda *a:None)
 def get_clock(self):return types.SimpleNamespace(now=lambda:types.SimpleNamespace(to_msg=lambda:None))
def mod(n,**kw):sys.modules[n]=types.SimpleNamespace(**kw)
mod('rclpy',init=lambda:None);mod('rclpy.node',Node=Node)
mod('geometry_msgs');mod('geometry_msgs.msg',TwistStamped=TS)
mod('std_msgs');mod('std_msgs.msg',String=String)
mod('turtlebot3_msgs');mod('turtlebot3_msgs.srv',Sound=object)
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
G=load('gate',root/'src/gnc_human_detection/gnc_human_detection/velocity_gate.py')
clock=[10.]
def status(g,dist,depth=True):g.on_status(String(json.dumps({'distances_m':dist,'depth_ok':depth})));g.tick()
with patch.object(G.time,'monotonic',lambda:clock[0]):
 g=G.VelocityGate();cmd=TS();cmd.twist.linear.x=.05;g.on_key(cmd)
 status(g,[]);assert g.state=='WAIT_CLEAR' and g.out.values[-1].twist.linear.x==0
 clock[0]+=.41;g.tick();assert g.state=='CLEAR' and g.out.values[-1].twist.linear.x==.05
 status(g,[.8]);assert g.state=='STOP' and g.out.values[-1].twist.linear.x==0 and g.indicator.values[-1].data=='RED' and g.stop_alerted
 status(g,[1.5]);assert g.state=='WAIT_CLEAR' and g.indicator.values[-1].data=='YELLOW'
 clock[0]+=.41;g.tick();assert g.state=='CLEAR' and not g.stop_alerted
 status(g,[1.8,.7]);assert g.state=='STOP' and g.indicator.values[-1].data=='RED'
 status(g,[]);assert g.state=='WAIT_CLEAR' and g.indicator.values[-1].data=='OFF'
 clock[0]+=.41;g.tick();assert g.state=='CLEAR'
 status(g,[None]);assert g.state=='FAULT'
 status(g,[],False);assert g.state=='FAULT'
 status(g,[]);clock[0]+=.7;g.tick();assert g.state=='FAULT' and g.out.values[-1].twist.linear.x==0
 status(g,[]);clock[0]+=.41;g.tick();clock[0]+=5
 status(g,[]);clock[0]+=.41;g.tick();assert g.out.values[-1].twist.linear.x==0
with patch.object(G.time,'monotonic',lambda:clock[0]):
 g=G.VelocityGate()
 g.allow_missing_perception=True
 g.command_timeout=.3
 g.tick()
 assert g.state=='WAIT_CLEAR'
 clock[0]+=.41;g.on_key(cmd);g.tick()
 assert g.state=='CLEAR' and g.out.values[-1].twist.linear.x==.05
 status(g,[1.0])
 assert g.state=='STOP' and g.out.values[-1].twist.linear.x==0
 clock[0]+=.61;g.on_key(cmd);g.tick()
 assert g.state=='WAIT_CLEAR' and g.out.values[-1].twist.linear.x==0
 clock[0]+=.41;g.on_key(cmd);g.tick()
 assert g.state=='CLEAR' and g.out.values[-1].twist.linear.x==.05
 clock[0]+=.31;g.tick()
 assert g.out.values[-1].twist.linear.x==0
class LED:
 def __init__(self,pin,**kwargs):self.pin=pin;self.value=False
 def off(self):self.value=False
 def close(self):pass
mod('gpiozero',LED=LED);mod('gpiozero.pins');mod('gpiozero.pins.lgpio',LGPIOFactory=lambda **kw:None)
L=load('led',root/'src/gnc_robot_io/gnc_robot_io/led_indicator.py')
with patch.object(L.time,'monotonic',lambda:clock[0]):
 n=L.Indicator();assert n.red.pin==16 and n.yellow.pin==20
 n.receive(String('RED'));n.tick();assert n.red.value and not n.yellow.value
 clock[0]+=.151;n.tick();assert not n.red.value
 n.receive(String('YELLOW'));n.tick();assert n.yellow.value and not n.red.value
 clock[0]+=.61;n.tick();assert not n.red.value and not n.yellow.value
 n.close()
print('PASS: stop/clear/fault, multiple-person priority, command expiry and LED timing/stale-status checks')
