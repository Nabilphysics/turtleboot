# UTM ROS 2 Jazzy workspace

Copy this folder to the UTM machine as `~/gnc_robot_ros`, or adjust the paths below if building alongside an existing workspace.

## Build


Keep the working Jazzy TF2 packages. The earlier setup recovered after
`tf2` and `tf2_ros` were aligned at 0.36.23.

```bash
sudo apt-get install python3-colcon-common-extensions python3-venv xterm \
  ros-jazzy-rmw-cyclonedds-cpp ros-jazzy-navigation2 ros-jazzy-nav2-bringup \
  ros-jazzy-slam-toolbox ros-jazzy-depth-image-proc ros-jazzy-rviz2 \
  ros-jazzy-cv-bridge ros-jazzy-turtlebot3-msgs ros-jazzy-turtlebot3-teleop
```

Reuse the working UTM detector environment by linking its `env` directory into
this workspace, or create it once using the recorded requirements:

```bash
cd ~/gnc_robot_ros
source /opt/ros/jazzy/setup.bash
python3 -m venv --system-site-packages env
env/bin/python -m pip install --extra-index-url https://download.pytorch.org/whl/cpu \
  -r scripts/detector-requirements.txt
```

The pinned versions reflect the supplied UTM environment and require matching
Python/ARM64 wheels. Then build:

```bash
cd ~/gnc_robot_ros
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
```

Start Pi robot bringup before using UTM. Run mapping and navigation separately. Navigation requires `map:=`. The command uses the included `my_map_v2.yaml`. To use your current `home_room_map.yaml`, copy it and its referenced image into `maps/` and change the argument. Set the initial pose in RViz before sending a goal.

## Navigation

```bash
source /opt/ros/jazzy/setup.bash
source ~/gnc_robot_ros/install/setup.bash
export ROS_DOMAIN_ID=30 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export GNC_ROOT="$HOME/gnc_robot_ros"
ros2 launch gnc_bringup navigation_split.launch.py \
  map:="$GNC_ROOT/maps/my_map_v2.yaml"
```

## Detection viewer

```bash
source /opt/ros/jazzy/setup.bash
source ~/gnc_robot_ros/install/setup.bash
export ROS_DOMAIN_ID=30 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export GNC_ROOT="$HOME/gnc_robot_ros"
ros2 launch gnc_bringup detection_viewer.launch.py
```

## Mapping

```bash
source /opt/ros/jazzy/setup.bash
source ~/gnc_robot_ros/install/setup.bash
export ROS_DOMAIN_ID=30 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export TURTLEBOT3_MODEL=burger
ros2 launch gnc_bringup mapping.launch.py
```

## Save the map while mapping is running

```bash
source /opt/ros/jazzy/setup.bash
source "$HOME/gnc_robot_ros/install/setup.bash"
export ROS_DOMAIN_ID=30 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
map_name=lab_map
mkdir -p "$HOME/gnc_robot_ros/maps"
ros2 run nav2_map_server map_saver_cli -f "$HOME/gnc_robot_ros/maps/$map_name" --ros-args -p save_map_timeout:=10.0
```
