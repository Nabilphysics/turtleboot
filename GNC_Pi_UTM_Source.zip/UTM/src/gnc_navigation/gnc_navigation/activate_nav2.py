"""Wait for localization, then configure/activate our navigation servers."""
import time
from pathlib import Path
import json

import rclpy
from lifecycle_msgs.srv import GetState, ChangeState
from lifecycle_msgs.msg import Transition
from tf2_ros import Buffer, TransformListener, TransformException
from rclpy.time import Time


def main():
    from ament_index_python.packages import get_package_share_directory
    root = Path(get_package_share_directory('gnc_navigation'))
    settings = {'base_frame': 'base_footprint'}
    names = json.loads((root / 'config/navigation_nodes.json').read_text())
    rclpy.init()
    node = rclpy.create_node('gnc_activation')
    buffer = Buffer()
    listener = TransformListener(buffer, node)
    print('Set 2D Pose Estimate in RViz. Waiting for map -> robot TF...', flush=True)
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            try:
                transform = buffer.lookup_transform('map', settings['base_frame'], Time())
                stamp = transform.header.stamp
                age = (node.get_clock().now().nanoseconds - stamp.sec*10**9 - stamp.nanosec)/1e9
                if -0.5 <= age <= 2.0:
                    break
            except TransformException:
                pass

        def call(client, request):
            while rclpy.ok() and not client.wait_for_service(timeout_sec=0.5):
                pass
            future = client.call_async(request)
            rclpy.spin_until_future_complete(node, future, timeout_sec=30)
            if not future.done():
                raise RuntimeError(f'Service timed out: {client.srv_name}')
            return future.result()

        for name in names:
            get = node.create_client(GetState, '/' + name + '/get_state')
            change = node.create_client(ChangeState, '/' + name + '/change_state')
            state = call(get, GetState.Request()).current_state.id
            if state == 1:  # unconfigured
                req = ChangeState.Request()
                req.transition.id = Transition.TRANSITION_CONFIGURE
                if not call(change, req).success:
                    raise RuntimeError(f'{name}: configure failed; inspect navigation log')
                state = call(get, GetState.Request()).current_state.id
            if state == 2:
                req = ChangeState.Request()
                req.transition.id = Transition.TRANSITION_ACTIVATE
                if not call(change, req).success:
                    raise RuntimeError(f'{name}: activate failed; inspect navigation log')
                state = call(get, GetState.Request()).current_state.id
            if state != 3:
                raise RuntimeError(f'{name}: unexpected lifecycle state {state}')
            print(f'{name}: active', flush=True)
        print('Navigation servers active. Inspect localization and command routing before a goal.', flush=True)
        # Stay alive so the startup supervisor can distinguish success from failure.
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
