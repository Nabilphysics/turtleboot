from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription,ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from gnc_bringup.helpers import share,required

def generate_launch_description():
    actions=[
        IncludeLaunchDescription(PythonLaunchDescriptionSource(str(share('slam_toolbox')/'launch/online_async_launch.py')),launch_arguments={'use_sim_time':'False','slam_params_file':str(share('gnc_navigation')/'config/mapping.yaml')}.items()),
        Node(package='rviz2',executable='rviz2',arguments=['-d',str(share('gnc_bringup')/'rviz/mapping.rviz')],output='screen')]
    actions+=required(ExecuteProcess(cmd=['xterm','-T','GNC mapping teleop','-e','ros2','run','turtlebot3_teleop','teleop_keyboard','--ros-args','-r','cmd_vel:=/gnc/velocity_requested','-p','enable_stamped_cmd_vel:=true'],output='screen'))
    return LaunchDescription(actions)
