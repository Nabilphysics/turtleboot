from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument,IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from gnc_bringup.helpers import share,required

def generate_launch_description():
    cfg=str(share('gnc_navigation')/'config/navigation.yaml')
    def include(path,args={}):return IncludeLaunchDescription(PythonLaunchDescriptionSource(str(path)),launch_arguments=args.items())
    actions=[DeclareLaunchArgument('map',description='Absolute path to map YAML'),
        include(share('nav2_bringup')/'launch/localization_launch.py',{'map':LaunchConfiguration('map'),'params_file':cfg,'use_sim_time':'False','use_composition':'False','autostart':'True'}),
        include(share('gnc_navigation')/'launch/nav2_servers.launch.py',{'params_file':cfg,'use_sim_time':'False','use_composition':'False','autostart':'False'}),
        Node(
            package='gnc_human_detection', executable='velocity_gate',
            output='screen',
            parameters=[{'output_topic': '/gnc/velocity_requested',
                         'command_timeout': 0.3, 'sound_enabled': False,
                         'allow_missing_perception': True}],
            remappings=[('/cmd_vel_teleop', '/gnc/nav_guarded'),
                        ('/gnc/human_indicator', '/gnc/nav_internal_indicator')],
        )]
    actions+=required(Node(package='gnc_navigation',executable='activate_nav2',output='screen'))
    actions.append(Node(package='rviz2',executable='rviz2',arguments=['-d',str(share('gnc_bringup')/'rviz/navigation_light.rviz')],output='screen',additional_env={'LIBGL_ALWAYS_SOFTWARE':'1'}))
    return LaunchDescription(actions)
