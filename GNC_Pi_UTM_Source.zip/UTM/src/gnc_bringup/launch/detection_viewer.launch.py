import os,shlex
from pathlib import Path
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument,OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def start(context):
    root=Path(os.environ.get('GNC_ROOT',str(Path.home()/'gnc_robot_ros')))
    python=root/'env/bin/python'
    if not python.is_file():raise RuntimeError('Set GNC_ROOT to the workspace containing env/bin/python')
    actions=[]
    actions.append(Node(package='gnc_human_detection',executable='calibration_relay',output='screen'))
    actions.append(Node(package='depth_image_proc',executable='register_node',name='l515_depth_registration',output='screen',parameters=[{'queue_size':5}],remappings=[
        ('depth/image_rect','/registration_input/depth/image_rect'),('depth/camera_info','/registration_input/depth/camera_info'),
        ('rgb/camera_info','/registration_input/rgb/camera_info'),('depth_registered/image_rect','/camera/depth_registered/image_rect'),
        ('depth_registered/camera_info','/camera/depth_registered/camera_info')]))
    actions.append(Node(
        package='gnc_human_detection', executable='velocity_gate',
        name='human_led_alert_gate', output='screen',
        parameters=[{'output_topic': '/gnc/led_test_velocity',
                     'command_timeout': 0.3, 'sound_enabled': False,
                     'allow_missing_perception': True}],
        remappings=[('/cmd_vel_teleop', '/gnc/led_test_input')],
    ))
    actions.append(Node(package='gnc_human_detection',executable='human_distance_gate',prefix=shlex.quote(str(python)),output='screen',parameters=[{'model_path':LaunchConfiguration('model_path').perform(context)}]))
    return actions

def generate_launch_description():
    root=Path(os.environ.get('GNC_ROOT',str(Path.home()/'gnc_robot_ros')))
    return LaunchDescription([DeclareLaunchArgument('model_path',default_value=str(root/'models/yolo11n.pt')),OpaqueFunction(function=start)])
