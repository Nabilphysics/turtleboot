import copy

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image, CameraInfo


class CalibrationRelay(Node):
    def __init__(self):
        super().__init__("calibration_relay")
        self.depth_info = None
        self.color_info = None
        qos = qos_profile_sensor_data

        self.depth_pub = self.create_publisher(
            Image, "/registration_input/depth/image_rect", 10)
        self.depth_info_pub = self.create_publisher(
            CameraInfo, "/registration_input/depth/camera_info", 10)
        self.color_info_pub = self.create_publisher(
            CameraInfo, "/registration_input/rgb/camera_info", 10)

        self.subs = [
            self.create_subscription(
                CameraInfo, "/camera/depth/camera_info",
                self.receive_depth_info, qos),
            self.create_subscription(
                CameraInfo, "/camera/color/camera_info",
                self.receive_color_info, qos),
            self.create_subscription(
                Image, "/camera/depth/image_rect_raw",
                self.receive_depth, qos),
        ]

    def receive_depth_info(self, msg):
        self.depth_info = msg

    def receive_color_info(self, msg):
        self.color_info = msg

    def receive_depth(self, msg):
        if self.depth_info is None or self.color_info is None:
            return

        if (msg.width, msg.height) != (
                self.depth_info.width, self.depth_info.height):
            return

        # Calibration describes fixed geometry, not a captured image.
        # Republish it for this depth frame without altering image time.
        depth_info = copy.deepcopy(self.depth_info)
        color_info = copy.deepcopy(self.color_info)
        depth_info.header.stamp = msg.header.stamp
        color_info.header.stamp = msg.header.stamp

        self.depth_info_pub.publish(depth_info)
        self.color_info_pub.publish(color_info)
        self.depth_pub.publish(msg)


def main():
    rclpy.init()
    node = CalibrationRelay()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
