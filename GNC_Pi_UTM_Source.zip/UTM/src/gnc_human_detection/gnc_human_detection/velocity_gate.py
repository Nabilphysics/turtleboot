import json
import math
import time

import rclpy
from geometry_msgs.msg import TwistStamped
from rclpy.node import Node
from std_msgs.msg import String
from turtlebot3_msgs.srv import Sound


class VelocityGate(Node):
    def __init__(self):
        super().__init__('human_velocity_gate')
        output = self.declare_parameter(
            'output_topic', '/human_stop/test_cmd_vel').value
        sound_enabled = self.declare_parameter('sound_enabled', False).value
        self.out = self.create_publisher(TwistStamped, output, 1)
        self.sound = self.create_client(Sound, '/sound') if sound_enabled else None
        self.create_subscription(TwistStamped, '/cmd_vel_teleop', self.on_key, 1)
        self.create_subscription(String, '/human_detection/status', self.on_status, 1)
        self.command_timeout = float(self.declare_parameter(
            'command_timeout', 5.0).value)
        self.allow_missing_perception = self.declare_parameter(
            "allow_missing_perception", False).value
        self.command = None
        self.key_time = 0.0
        self.status_time = 0.0
        self.status = 'FAULT'
        self.stop_alerted = False
        self.person_far = False
        self.indicator = self.create_publisher(String, '/gnc/human_indicator', 1)
        self.clear_since = None
        self.state = None
        self.beeps = []
        self.create_timer(0.05, self.tick)

    def on_key(self, msg):
        self.command = msg
        self.key_time = time.monotonic()

    def on_status(self, msg):
        # One entry per person: metres, or null if distance is unavailable.
        # An empty list means the detector processed a frame and saw nobody.
        self.status_time = time.monotonic()
        self.person_far = False
        try:
            payload = json.loads(msg.data)
            if payload.get('depth_ok') is not True:
                raise ValueError('No usable matched depth')
            distances = payload['distances_m']
            if not isinstance(distances, list):
                raise ValueError('distances_m must be a list')
            valid = [
                d for d in distances
                if type(d) in (float, int) and math.isfinite(d) and d > 0
            ]
            if any(d <= 1.0 for d in valid):
                self.status = 'STOP'
            elif len(valid) != len(distances):
                self.status = 'FAULT'
            else:
                self.status = 'CLEAR'
                self.person_far = bool(valid)
        except (ValueError, TypeError, KeyError, OverflowError):
            self.status = 'FAULT'
        if self.status == 'STOP' or (self.status == 'FAULT' and not self.allow_missing_perception):
            self.clear_since = None

    def tick(self):
        now = time.monotonic()
        status = self.status if now - self.status_time <= 0.6 else 'FAULT'
        if status == 'CLEAR' or (status == 'FAULT' and self.allow_missing_perception):
            if self.clear_since is None:
                self.clear_since = now
            state = 'CLEAR' if now - self.clear_since >= 0.4 else 'WAIT_CLEAR'
        else:
            self.clear_since = None
            state = status

        if state == 'CLEAR':
            self.stop_alerted = False

        if state != self.state:
            self.state = state
            self.get_logger().info(f'State: {state}')
            self.beeps = (
                [now] if state == 'STOP' and not self.stop_alerted
                else [] if state == 'FAULT'
                else []
            )

            if state == 'STOP':
                self.stop_alerted = True

        mode = 'RED' if state == 'STOP' else ('YELLOW' if status == 'CLEAR' and self.person_far else 'OFF')
        self.indicator.publish(String(data=mode))

        output = TwistStamped()
        output.header.stamp = self.get_clock().now().to_msg()
        if state == 'CLEAR' and self.command and now - self.key_time <= self.command_timeout:
            output.header.frame_id = self.command.header.frame_id
            output.twist = self.command.twist
        self.out.publish(output)

        if self.beeps and now >= self.beeps[0]:
            self.beeps.pop(0)
            self.get_logger().info(f'Alert pulse: {state}')
            if self.sound is not None and self.sound.service_is_ready():
                request = Sound.Request()
                request.value = 1
                self.sound.call_async(request)


def main():
    rclpy.init()
    node = VelocityGate()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
