#!/usr/bin/env python3
import threading
import time
from collections import deque
from pathlib import Path

import cv2
import numpy as np
import rclpy
import torch
from cv_bridge import CvBridge
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from sensor_msgs.msg import Image


def timestamp(msg):
    return msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9


class HumanDistance(Node):
    def __init__(self):
        super().__init__("human_distance")
        self.bridge = CvBridge()
        self.lock = threading.Lock()
        self.rgb = deque(maxlen=10)
        self.depth = deque(maxlen=120)

        qos = QoSProfile(
            depth=1,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
        )
        self.rgb_sub = self.create_subscription(
            Image, "/camera/color/image_raw", self.receive_rgb, qos
        )
        self.depth_sub = self.create_subscription(
            Image, "/camera/depth_registered/image_rect",
            self.receive_depth, qos
        )
        self.publisher = self.create_publisher(
            Image, "/human_detection/image", qos
        )

    def receive_rgb(self, msg):
        with self.lock:
            self.rgb.append((msg, time.monotonic()))

    def receive_depth(self, msg):
        with self.lock:
            self.depth.append(msg)

    def take_pair(self):
        with self.lock:
            if not self.rgb:
                return None

            rgb, received = self.rgb[-1]
            self.rgb.clear()

            if time.monotonic() - received > 0.75:
                return None

            candidates = [
                d for d in self.depth
                if (d.width, d.height) == (rgb.width, rgb.height)
            ]

            depth = None
            if candidates:
                nearest = min(
                    candidates,
                    key=lambda d: abs(timestamp(d) - timestamp(rgb))
                )
                if abs(timestamp(nearest) - timestamp(rgb)) <= 0.20:
                    depth = nearest

            return rgb, depth


def estimate_depth(depth, box):
    height, width = depth.shape
    x1, y1, x2, y2 = map(float, box)

    # Sample the central portion to reduce background contamination.
    left = max(0, min(width, int(x1 + 0.30 * (x2 - x1))))
    right = max(0, min(width, int(x2 - 0.30 * (x2 - x1))))
    top = max(0, min(height, int(y1 + 0.25 * (y2 - y1))))
    bottom = max(0, min(height, int(y2 - 0.25 * (y2 - y1))))

    roi = depth[top:bottom, left:right]
    if roi.size == 0:
        return None

    valid = roi[np.isfinite(roi) & (roi >= 0.25) & (roi <= 9.0)]
    required = max(10, int(roi.size * 0.10))
    if valid.size < required:
        return None

    return float(np.median(valid))


def spin_node(node):
    try:
        rclpy.spin(node)
    except ExternalShutdownException:
        pass


def main():
    import json
    from std_msgs.msg import String
    from ultralytics import YOLO

    rclpy.init()
    node = HumanDistance()
    status_pub = node.create_publisher(String, '/human_detection/status', 1)
    torch.set_num_threads(2)
    model_path = node.declare_parameter('model_path', str(Path.home() / 'gnc_robot/models/yolo11n.pt')).value
    model = YOLO(model_path)

    worker = threading.Thread(
        target=spin_node, args=(node,), daemon=True
    )
    worker.start()

    cv2.namedWindow("Human Detection + Distance", cv2.WINDOW_NORMAL)
    node.get_logger().info(
        "Waiting for RGB and aligned depth. Press Q to exit."
    )
    last_log = 0.0

    try:
        while rclpy.ok():
            pair = node.take_pair()
            if pair is None:
                if cv2.waitKey(10) & 0xFF == ord("q"):
                    break
                time.sleep(0.01)
                continue

            rgb_msg, depth_msg = pair
            frame = node.bridge.imgmsg_to_cv2(rgb_msg, "bgr8")

            depth = None
            if depth_msg is not None:
                raw = node.bridge.imgmsg_to_cv2(
                    depth_msg, "passthrough"
                )
                if depth_msg.encoding == "16UC1":
                    depth = raw.astype(np.float32) * 0.001
                elif depth_msg.encoding == "32FC1":
                    depth = raw

                if depth is not None and depth.shape != frame.shape[:2]:
                    depth = None

            result = model.predict(
                frame, classes=[0], conf=0.60,
                imgsz=320, device="cpu", verbose=False
            )[0]

            reports = []
            distances_m = []
            for box in result.boxes:
                coords = box.xyxy[0].cpu().numpy()
                confidence = float(box.conf[0].item())
                z = (
                    estimate_depth(depth, coords)
                    if depth is not None else None
                )

                distance = (
                    f"{z:.2f} m" if z is not None
                    else "distance unavailable"
                )
                label = f"Person {confidence:.2f} | {distance}"
                reports.append(distance)
                distances_m.append(None if z is None else float(z))

                x1, y1, x2, y2 = map(int, coords)
                cv2.rectangle(
                    frame, (x1, y1), (x2, y2), (0, 255, 0), 2
                )
                cv2.putText(
                    frame, label, (max(0, x1), max(20, y1 - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2
                )

            cv2.putText(
                frame, f"People: {len(result.boxes)}",
                (10, 25), cv2.FONT_HERSHEY_SIMPLEX,
                0.6, (0, 255, 255), 2
            )

            output = node.bridge.cv2_to_imgmsg(frame, "bgr8")
            output.header = rgb_msg.header
            node.publisher.publish(output)
            rgb_stamp = rgb_msg.header.stamp
            status_pub.publish(String(data=json.dumps({
                'distances_m': distances_m,
                'depth_ok': bool(depth is not None and ((depth >= 0.25) & (depth <= 9.0)).any()),
                'rgb_stamp_ns': rgb_stamp.sec * 10**9 + rgb_stamp.nanosec,
            })))
            cv2.imshow("Human Detection + Distance", frame)

            now = time.monotonic()
            if now - last_log >= 2.0:
                node.get_logger().info(
                    f"People: {len(reports)}; depths: {reports}"
                )
                last_log = now

            if cv2.waitKey(10) & 0xFF == ord("q"):
                break
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()
        worker.join(timeout=3)
        node.destroy_node()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
