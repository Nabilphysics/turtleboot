# Third-party notices

- The RealSense ROS wrapper source was supplied from the working Pi workspace. Its Apache-2.0 LICENSE and NOTICE remain in src/realsense-ros.
- The supplied yolo11n.pt weights are part of the Ultralytics ecosystem, offered under AGPL-3.0 or an applicable Enterprise license. A copy of AGPL-3.0 is included. See https://www.ultralytics.com/license and https://github.com/ultralytics/ultralytics . Check obligations for your distribution/use; inclusion here does not grant a separate proprietary license. The installer obtains the corresponding pinned Ultralytics source distribution through pip.
- The included Nav2 navigation launch was derived from the installed ROS Jazzy nav2_bringup launch, retaining its architecture and removing docking. Upstream Navigation2 is Apache-2.0: https://github.com/ros-navigation/navigation2 .
- Custom GNC additions are Apache-2.0. No university or third-party endorsement is implied.
- Other system and Python dependencies retain their respective licenses and are downloaded by their package managers, not bundled as binaries.
