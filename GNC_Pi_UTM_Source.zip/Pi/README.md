# Pi ROS 2 Jazzy workspace

Copy this folder to the Pi machine as `~/gnc_robot_ros`, or adjust the paths below if building alongside an existing workspace.

## Build


Use your working TurtleBot3 underlay and librealsense 2.53.1 installation.
For a fresh ROS Jazzy system, install the prerequisites first. If the
TurtleBot3 underlay is missing, install the TurtleBot3 packages and verify
Burger/OpenCR/LDS-02 bringup before running Nav2.

```bash
sudo apt-get install python3-colcon-common-extensions ros-jazzy-ros-base \
  ros-jazzy-rmw-cyclonedds-cpp ros-jazzy-cv-bridge ros-jazzy-image-transport \
  ros-jazzy-diagnostic-updater ros-jazzy-xacro ros-jazzy-rosidl-default-generators \
  python3-gpiozero python3-lgpio libeigen3-dev
```

If librealsense 2.53.1 is absent, run `bash scripts/install_sdk.sh` from the
workspace. The LED node needs read/write access to `/dev/gpiochip0` as your
normal Pi user. Reuse your working GPIO permissions. On a fresh Pi, a
dedicated group and a udev rule can grant access to that chip:

```bash
getent group gpio >/dev/null || sudo groupadd --system gpio
sudo usermod -aG gpio "$USER"
printf '%s\n' 'SUBSYSTEM=="gpio", KERNEL=="gpiochip0", GROUP="gpio", MODE="0660"' \
  | sudo tee /etc/udev/rules.d/99-gnc-gpio.rules
sudo udevadm control --reload-rules
sudo udevadm trigger --action=change --subsystem-match=gpio
```

Log out and back in after changing group membership. Then build:

```bash
cd ~/gnc_robot_ros
source /opt/ros/jazzy/setup.bash
source ~/turtlebot3_ws/install/setup.bash  # Skip if TurtleBot3 is installed in the Jazzy underlay.
export CMAKE_BUILD_PARALLEL_LEVEL=1 MAKEFLAGS="-j1 -l1"
colcon build --symlink-install --executor sequential \
  --cmake-args -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF
```

## Robot bringup

```bash
source /opt/ros/jazzy/setup.bash
source ~/turtlebot3_ws/install/setup.bash
source ~/gnc_robot_ros/install/local_setup.bash
export ROS_DOMAIN_ID=30 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
ros2 launch gnc_bringup robot.launch.py mode:=mapping \
  usb_port:=/dev/serial/by-id/usb-ROBOTIS_OpenCR_Virtual_ComPort_in_FS_Mode_FFFFFFFEFFFF-if00
```

## RealSense and LED

```bash
source /opt/ros/jazzy/setup.bash
source ~/gnc_robot_ros/install/setup.bash
export ROS_DOMAIN_ID=30 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
ros2 launch gnc_bringup camera_led.launch.py
```
