#!/usr/bin/env bash
set -eo pipefail
root=$(cd -- "$(dirname -- "$0")/.." && pwd)
version=$(pkg-config --modversion realsense2 2>/dev/null || true)
if [[ "$version" == 2.53.1 ]]; then
  echo "librealsense 2.53.1 already installed."
  exit 0
fi
if [[ -n "$version" ]]; then
  echo "Found librealsense $version; refusing to overwrite it. Resolve SDK versions first." >&2
  exit 1
fi
sudo apt-get install -y git cmake build-essential pkg-config libusb-1.0-0-dev libudev-dev libssl-dev
mkdir -p "$root/vendor"
if [[ ! -d "$root/vendor/librealsense/.git" ]]; then
  git clone --depth 1 --branch v2.53.1 https://github.com/realsenseai/librealsense.git "$root/vendor/librealsense"
fi
sdk="$root/vendor/librealsense"
[[ $(git -C "$sdk" describe --tags --exact-match) == v2.53.1 ]]
cmake -S "$sdk" -B "$sdk/build" -DCMAKE_BUILD_TYPE=Release -DFORCE_RSUSB_BACKEND=ON \
  -DBUILD_EXAMPLES=OFF -DBUILD_TOOLS=ON -DBUILD_GRAPHICAL_EXAMPLES=OFF \
  -DBUILD_GLSL_EXTENSIONS=OFF -DBUILD_UNIT_TESTS=OFF -DBUILD_PYTHON_BINDINGS=OFF
cmake --build "$sdk/build" --parallel 1
sudo cmake --install "$sdk/build"
sudo ldconfig
# Install the exact SDK rules without an interactive camera-removal prompt.
sudo install -m 644 "$sdk/config/99-realsense-libusb.rules" /etc/udev/rules.d/99-realsense-libusb.rules
sudo udevadm control --reload-rules
echo 'Reconnect the camera after installation. Do not run multiple camera drivers.'
