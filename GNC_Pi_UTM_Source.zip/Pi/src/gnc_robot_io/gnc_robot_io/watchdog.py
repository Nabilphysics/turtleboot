"""Pi-local command expiry. No camera or navigation logic lives here."""
import math
import time

import rclpy
from geometry_msgs.msg import TwistStamped
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy


class Watchdog(Node):
    def __init__(self):
        super().__init__('gnc_watchdog')
        self.timeout = float(self.declare_parameter('timeout', 0.3).value)
        if self.timeout <= 0:
            raise ValueError('timeout must be positive')
        self.last = float('-inf')
        self.command = None
        qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.BEST_EFFORT)
        self.sub = self.create_subscription(TwistStamped, '/gnc/velocity_requested', self.receive, qos)
        self.pub = self.create_publisher(TwistStamped, '/cmd_vel', 1)
        self.timer = self.create_timer(0.05, self.tick)

    def receive(self, msg):
        values = [msg.twist.linear.x, msg.twist.linear.y, msg.twist.linear.z,
                  msg.twist.angular.x, msg.twist.angular.y, msg.twist.angular.z]
        if not all(math.isfinite(v) for v in values):
            self.command = None
            return
        self.last = time.monotonic()
        self.command = msg

    def tick(self):
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        if self.command is not None and time.monotonic() - self.last < self.timeout:
            msg.header.frame_id = self.command.header.frame_id
            msg.twist = self.command.twist
        self.pub.publish(msg)


def main():
    rclpy.init()
    node = Watchdog()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Best effort normal-exit stop; it cannot protect against SIGKILL/crash.
        if rclpy.ok():
            for _ in range(5):
                msg = TwistStamped()
                msg.header.stamp = node.get_clock().now().to_msg()
                node.pub.publish(msg)
                time.sleep(0.03)
            rclpy.shutdown()
        node.destroy_node()


if __name__ == '__main__':
    main()
