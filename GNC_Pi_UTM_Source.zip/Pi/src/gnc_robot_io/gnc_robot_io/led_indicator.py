"""BCM16 red, BCM20 yellow; 150 ms per half-cycle; off on stale status."""
import time
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
class Indicator(Node):
    def __init__(self):
        super().__init__('gnc_led_indicator')
        from gpiozero import LED
        from gpiozero.pins.lgpio import LGPIOFactory
        factory=LGPIOFactory(chip=int(self.declare_parameter('gpio_chip',0).value))
        self.red=LED(int(self.declare_parameter('red_gpio',16).value),pin_factory=factory)
        self.yellow=LED(int(self.declare_parameter('yellow_gpio',20).value),pin_factory=factory)
        self.mode='OFF';self.last=float('-inf');self.origin=time.monotonic()
        self.sub=self.create_subscription(String,'/gnc/human_indicator',self.receive,1)
        self.timer=self.create_timer(0.025,self.tick)
    def receive(self,msg):
        mode=msg.data if msg.data in ('RED','YELLOW','OFF') else 'OFF'
        if mode!=self.mode:self.origin=time.monotonic()
        self.mode=mode;self.last=time.monotonic()
    def tick(self):
        now=time.monotonic()
        mode=self.mode if now-self.last<0.6 else 'OFF'
        on=int((now-self.origin)/0.15)%2==0
        self.red.value=on and mode=='RED'
        self.yellow.value=on and mode=='YELLOW'
    def close(self):
        self.red.off();self.yellow.off();self.red.close();self.yellow.close()
def main():
    rclpy.init();node=None
    try:
        node=Indicator();rclpy.spin(node)
    except KeyboardInterrupt:pass
    finally:
        if node:node.close();node.destroy_node()
        if rclpy.ok():rclpy.shutdown()
if __name__=='__main__':main()
