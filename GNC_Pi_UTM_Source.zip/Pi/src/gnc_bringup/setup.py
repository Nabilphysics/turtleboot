from setuptools import setup
from pathlib import Path
name='gnc_bringup'
data=[('share/ament_index/resource_index/packages', ['resource/'+name]), ('share/'+name, ['package.xml'])]
for folder in ('launch','config','rviz'):
    for p in Path(folder).rglob('*'):
        if p.is_file(): data.append(('share/'+name+'/'+str(p.parent), [str(p)]))
setup(name=name,version='0.1.0',packages=[name],data_files=data,install_requires=['setuptools'],zip_safe=True,
      maintainer='GNC team',maintainer_email='maintainer@example.com',description='GNC robot system',license='Apache-2.0',
      entry_points={'console_scripts':[]})
