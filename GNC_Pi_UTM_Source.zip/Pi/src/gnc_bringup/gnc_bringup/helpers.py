from pathlib import Path
from ament_index_python.packages import get_package_share_directory
from launch.actions import RegisterEventHandler,EmitEvent
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
def share(package):return Path(get_package_share_directory(package))
def required(action):
    return [action, RegisterEventHandler(OnProcessExit(target_action=action,on_exit=[EmitEvent(event=Shutdown(reason='Required process exited'))]))]
