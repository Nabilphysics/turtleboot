from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

from gnc_bringup.helpers import share


def generate_launch_description():
    camera_launch = share('realsense2_camera') / 'launch/rs_launch.py'
    robot_config = share('gnc_bringup') / 'config/robot.yaml'
    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(str(camera_launch)),
            launch_arguments={
                'enable_color': 'true',
                'rgb_camera.profile': '640x360x15',
                'enable_depth': 'true',
                'depth_module.profile': '320x240x30',
                'enable_infra': 'false',
                'enable_confidence': 'false',
                'enable_accel': 'false',
                'enable_gyro': 'false',
                'pointcloud.enable': 'false',
            }.items(),
        ),
        Node(
            package='gnc_robot_io', executable='led_indicator',
            parameters=[str(robot_config)], output='screen',
        ),
    ])
