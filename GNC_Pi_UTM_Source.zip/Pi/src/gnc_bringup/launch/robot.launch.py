from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument,IncludeLaunchDescription,OpaqueFunction,SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from gnc_bringup.helpers import share,required

def start(context):
    mode=LaunchConfiguration('mode').perform(context)
    if mode not in ('mapping','navigation'):raise ValueError('mode must be mapping or navigation')
    model=LaunchConfiguration('model').perform(context)
    lidar=LaunchConfiguration('lidar').perform(context)
    actions=[SetEnvironmentVariable('TURTLEBOT3_MODEL',model),SetEnvironmentVariable('LDS_MODEL',lidar),SetEnvironmentVariable('OPENCR_MODEL',model)]
    actions.append(IncludeLaunchDescription(PythonLaunchDescriptionSource(str(share('turtlebot3_bringup')/'launch/robot.launch.py')), launch_arguments={'usb_port': LaunchConfiguration('usb_port')}.items()))
    watchdog=Node(package='gnc_robot_io',executable='watchdog',output='screen',parameters=[str(share('gnc_bringup')/'config/robot.yaml')])
    actions+=required(watchdog)
    if mode=='navigation':
        camera=IncludeLaunchDescription(PythonLaunchDescriptionSource(str(share('realsense2_camera')/'launch/rs_launch.py')),launch_arguments={
            'enable_depth':'true','enable_color':'true','enable_accel':'false','enable_gyro':'false',
            'depth_module.profile':'320x240x30','rgb_camera.profile':'640x480x15',
            'enable_sync':'false','align_depth.enable':'false','pointcloud.enable':'false'}.items())
        actions.append(camera)
        if LaunchConfiguration('leds').perform(context).lower()=='true':
            actions+=required(Node(package='gnc_robot_io',executable='led_indicator',output='screen',parameters=[str(share('gnc_bringup')/'config/robot.yaml')]))
    return actions

def generate_launch_description():
    return LaunchDescription([DeclareLaunchArgument('mode',default_value='navigation'),DeclareLaunchArgument('model',default_value='burger'),DeclareLaunchArgument('lidar',default_value='LDS-02'),DeclareLaunchArgument('usb_port',default_value='/dev/ttyACM0'),DeclareLaunchArgument('leds',default_value='true'),OpaqueFunction(function=start)])
